import java.util.*;
public class ConversionBench {
    public static void main(String[] a) {
        Random r = new Random(1);
        int N = 1 << 16;
        long[] sig = new long[N]; int[] exp = new int[N];
        for (int i = 0; i < N; i++) { sig[i] = 1 + Math.abs(r.nextLong()) % 9_999_999_999_999_999L; exp[i] = -300 + r.nextInt(600); }
        double sink = 0;
        for (int round = 0; round < 6; round++) {
            long t0 = System.nanoTime();
            for (int k = 0; k < 20; k++) for (int i = 0; i < N; i++) sink += Decimal64.toDoubleEiselLemire(sig[i], exp[i]);
            long t1 = System.nanoTime();
            for (int i = 0; i < N; i++) sink += Decimal64.toDoubleSlow(sig[i], exp[i]);
            long t2 = System.nanoTime();
            for (int k = 0; k < 2; k++) for (int i = 0; i < N; i++) sink += Double.parseDouble(sig[i] + "E" + exp[i]);
            long t3 = System.nanoTime();
            if (round >= 4) System.out.printf("Eisel-Lemire %.1f ns | bignum slow %.1f ns | parseDouble(String) %.1f ns%n",
                (t1 - t0) / (20.0 * N), (t2 - t1) / (double) N, (t3 - t2) / (2.0 * N));
        }
        System.out.println(sink > 0);
    }
}
