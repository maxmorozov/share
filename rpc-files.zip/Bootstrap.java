package com.example.rpc.example;

import com.example.rpc.core.RpcChannel;
import com.example.rpc.core.RpcException;
import com.example.rpc.generated.QuoteMessages.QuoteUpdate;
import com.example.rpc.generated.QuoteServiceClient;
import com.example.rpc.transport.liberator.LiberatorChannel;
import com.example.rpc.transport.liberator.LiberatorTransport;
import com.example.rpc.transport.ws.WebSocketChannel;
import com.example.rpc.transport.ws.WsTransport;

/**
 * Shows that application code only ever depends on QuoteServiceClient and
 * RpcChannel - swapping Liberator for WebSocket is a one-line change at the
 * composition root, nothing else in the app needs to change.
 */
public final class Bootstrap {

    public static void main(String[] args) {
        boolean useLiberator = Boolean.parseBoolean(System.getProperty("useLiberator", "false"));

        RpcChannel channel = useLiberator
                ? new LiberatorChannel(liberatorTransport(), "RPC.REPLY.", 10)
                : new WebSocketChannel(webSocketTransport(), 10);

        QuoteServiceClient quotes = new QuoteServiceClient(channel);

        quotes.getQuote("EURUSD")
                .thenAccept(resp -> System.out.printf("EURUSD %.5f/%.5f%n", resp.bid, resp.ask))
                .exceptionally(err -> { System.err.println("getQuote failed: " + err); return null; });

        RpcChannel.Subscription sub = quotes.subscribeQuotes("EURUSD", new RpcChannel.StreamObserver<QuoteUpdate>() {
            @Override public void onNext(QuoteUpdate value) {
                System.out.printf("update EURUSD %.5f/%.5f @ %d%n", value.bid, value.ask, value.timestampMillis);
            }
            @Override public void onError(RpcException error) {
                System.err.println("stream failed: " + error.code() + " " + error.getMessage());
            }
            @Override public void onCompleted() {
                System.out.println("stream closed");
            }
        });

        // ... later, when no longer interested: sub.cancel();
    }

    private static LiberatorTransport liberatorTransport() {
        // Plug in a real adapter over com.caplin.streamlink.* here.
        throw new UnsupportedOperationException("wire up your StreamLink client");
    }

    private static WsTransport webSocketTransport() {
        // Plug in a real adapter over your WebSocket client of choice here.
        throw new UnsupportedOperationException("wire up your WebSocket client");
    }
}
