package com.example.rpc.codec;

import com.example.rpc.core.RpcMessage;

import java.util.Map;

/**
 * Bridges a message type to a transport-specific wire representation. Kept
 * separate from RpcChannel so encoding rules can be swapped or tested
 * independently of the transport that actually carries the bytes.
 */
public interface Codec<T extends RpcMessage> {

    Payload encode(T message);
    T decode(Payload payload);

    /** Wire payload produced by a codec; each transport only accepts one variant. */
    sealed interface Payload {
        record Bytes(byte[] data) implements Payload {}
        record FieldMap(Map<String, String> fields) implements Payload {}
    }

    /** Used by WebSocketChannel - binary protobuf encoding. */
    final class Protobuf<T extends RpcMessage> implements Codec<T> {
        private final RpcMessage.Parser<T> parser;

        public Protobuf(RpcMessage.Parser<T> parser) {
            this.parser = parser;
        }

        @Override
        public Payload encode(T message) {
            return new Payload.Bytes(message.toBytes());
        }

        @Override
        public T decode(Payload payload) {
            if (!(payload instanceof Payload.Bytes bytes)) {
                throw new IllegalArgumentException("Protobuf codec expects a Bytes payload");
            }
            return parser.fromBytes(bytes.data());
        }
    }

    /** Used by LiberatorChannel - flat StreamLink field records. */
    final class FieldMap<T extends RpcMessage> implements Codec<T> {
        private final RpcMessage.Parser<T> parser;

        public FieldMap(RpcMessage.Parser<T> parser) {
            this.parser = parser;
        }

        @Override
        public Payload encode(T message) {
            return new Payload.FieldMap(message.toFieldMap());
        }

        @Override
        public T decode(Payload payload) {
            if (!(payload instanceof Payload.FieldMap fields)) {
                throw new IllegalArgumentException("FieldMap codec expects a FieldMap payload");
            }
            return parser.fromFieldMap(fields.fields());
        }
    }
}
