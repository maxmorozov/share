package com.example.rpc.transport.liberator;

import com.example.rpc.core.MethodDescriptor;
import com.example.rpc.core.RpcChannel;
import com.example.rpc.core.RpcException;
import com.example.rpc.core.RpcMessage;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * RpcChannel over Caplin StreamLink. Server-streaming methods map directly onto
 * StreamLink subscriptions; unary methods are emulated with "publish a form,
 * subscribe to a per-request reply subject" - StreamLink itself has no built-in
 * request/response primitive.
 */
public final class LiberatorChannel implements RpcChannel {

    private final LiberatorTransport transport;
    private final String replySubjectPrefix;
    private final long defaultTimeoutSeconds;
    private final ScheduledExecutorService timers = Executors.newSingleThreadScheduledExecutor();

    public LiberatorChannel(LiberatorTransport transport, String replySubjectPrefix, long defaultTimeoutSeconds) {
        this.transport = transport;
        this.replySubjectPrefix = replySubjectPrefix;
        this.defaultTimeoutSeconds = defaultTimeoutSeconds;
    }

    @Override
    public <Req extends RpcMessage, Res extends RpcMessage> CompletableFuture<Res> unary(
            MethodDescriptor<Req, Res> method, Req request) {

        String requestId = UUID.randomUUID().toString();
        String replySubject = replySubjectPrefix + requestId;
        CompletableFuture<Res> future = new CompletableFuture<>();

        transport.subscribe(replySubject, new LiberatorTransport.LiberatorListener() {
            @Override
            public void onFields(Map<String, String> fields, boolean isImage) {
                transport.unsubscribe(replySubject);
                try {
                    future.complete(method.responseParser().fromFieldMap(fields));
                } catch (Exception e) {
                    future.completeExceptionally(
                            new RpcException(RpcException.StatusCode.INTERNAL, "decode failed", e));
                }
            }

            @Override
            public void onSubscriptionFailed(String reason) {
                future.completeExceptionally(new RpcException(RpcException.StatusCode.UNAVAILABLE, reason));
            }

            @Override
            public void onStale() {
                // Reply subject briefly unreachable but subscription is alive;
                // for a single-shot reply we just keep waiting for the real answer.
            }
        });

        Map<String, String> fields = new HashMap<>(request.toFieldMap());
        fields.put("_requestId", requestId);
        fields.put("_replyTo", replySubject);
        transport.publishForm(method.fullName(), fields);

        ScheduledFuture<?> timeout = timers.schedule(() -> {
            if (future.completeExceptionally(
                    new RpcException(RpcException.StatusCode.DEADLINE_EXCEEDED, "timeout: " + method.fullName()))) {
                transport.unsubscribe(replySubject);
            }
        }, defaultTimeoutSeconds, TimeUnit.SECONDS);
        future.whenComplete((r, e) -> timeout.cancel(false));

        return future;
    }

    @Override
    public <Req extends RpcMessage, Res extends RpcMessage> Subscription serverStream(
            MethodDescriptor<Req, Res> method, Req request, StreamObserver<Res> observer) {

        String subject = subjectFor(method, request);

        transport.subscribe(subject, new LiberatorTransport.LiberatorListener() {
            @Override
            public void onFields(Map<String, String> fields, boolean isImage) {
                try {
                    observer.onNext(method.responseParser().fromFieldMap(fields));
                } catch (Exception e) {
                    observer.onError(new RpcException(RpcException.StatusCode.INTERNAL, "decode failed", e));
                }
            }

            @Override
            public void onSubscriptionFailed(String reason) {
                observer.onError(new RpcException(RpcException.StatusCode.UNAVAILABLE, reason));
            }

            @Override
            public void onStale() {
                // Optionally surface as a soft health signal to the app; StreamLink
                // will refresh the record automatically once connectivity returns.
            }
        });

        return () -> transport.unsubscribe(subject);
    }

    /** e.g. "QuoteService/SubscribeQuotes.EURUSD" - StreamLink subjects are plain strings. */
    private String subjectFor(MethodDescriptor<?, ?> method, RpcMessage request) {
        Map<String, String> fields = request.toFieldMap();
        StringBuilder subject = new StringBuilder(method.fullName());
        fields.values().forEach(v -> subject.append('.').append(v));
        return subject.toString();
    }

    public void shutdown() {
        timers.shutdownNow();
    }
}
