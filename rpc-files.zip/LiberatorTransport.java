package com.example.rpc.transport.liberator;

import java.util.Map;

/**
 * Thin wrapper around the actual Caplin StreamLink SDK. A concrete implementation
 * delegates to StreamLink's own subscribe/unsubscribe/publish calls; LiberatorChannel
 * only depends on this interface, never on StreamLink classes directly.
 */
public interface LiberatorTransport {
    void subscribe(String subject, LiberatorListener listener);
    void unsubscribe(String subject);
    void publishForm(String subject, Map<String, String> fields);

    /** Mirrors StreamLink's page/record callback shape. */
    interface LiberatorListener {
        void onFields(Map<String, String> fields, boolean isImage);
        void onSubscriptionFailed(String reason);
        void onStale();
    }
}
