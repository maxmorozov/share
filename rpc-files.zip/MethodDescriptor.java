package com.example.rpc.core;

import java.util.Objects;

/**
 * Transport-agnostic description of one RPC method. Generated once per method
 * from the .proto service definition and shared by every channel implementation.
 */
public final class MethodDescriptor<Req extends RpcMessage, Res extends RpcMessage> {

    public enum Type { UNARY, SERVER_STREAM }

    private final String serviceName;
    private final String methodName;
    private final Type type;
    private final RpcMessage.Parser<Res> responseParser;

    private MethodDescriptor(String serviceName, String methodName, Type type,
                              RpcMessage.Parser<Res> responseParser) {
        this.serviceName = Objects.requireNonNull(serviceName);
        this.methodName = Objects.requireNonNull(methodName);
        this.type = Objects.requireNonNull(type);
        this.responseParser = Objects.requireNonNull(responseParser);
    }

    public static <Req extends RpcMessage, Res extends RpcMessage> MethodDescriptor<Req, Res> unary(
            String serviceName, String methodName, RpcMessage.Parser<Res> responseParser) {
        return new MethodDescriptor<>(serviceName, methodName, Type.UNARY, responseParser);
    }

    public static <Req extends RpcMessage, Res extends RpcMessage> MethodDescriptor<Req, Res> serverStream(
            String serviceName, String methodName, RpcMessage.Parser<Res> responseParser) {
        return new MethodDescriptor<>(serviceName, methodName, Type.SERVER_STREAM, responseParser);
    }

    public String serviceName() { return serviceName; }
    public String methodName() { return methodName; }
    public Type type() { return type; }
    public RpcMessage.Parser<Res> responseParser() { return responseParser; }

    /** e.g. "QuoteService/GetQuote" - used as the WS envelope method id and the Liberator subject root. */
    public String fullName() { return serviceName + "/" + methodName; }
}
