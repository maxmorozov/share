package com.example.rpc.generated;

import com.example.rpc.core.RpcMessage;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Hand-written stand-ins for what a protoc plugin would actually generate from
 * quote_service.proto. Real generated classes use protobuf's own binary encoding
 * for toBytes()/fromBytes() and a codegen-emitted field-name mapping for
 * toFieldMap()/fromFieldMap() - shown here in simplified form for clarity.
 */
public final class QuoteMessages {

    public static final class GetQuoteRequest implements RpcMessage {
        public final String symbol;
        public GetQuoteRequest(String symbol) { this.symbol = symbol; }

        @Override public byte[] toBytes() { return writeUtf8(symbol); }
        @Override public Map<String, String> toFieldMap() {
            Map<String, String> m = new HashMap<>();
            m.put("symbol", symbol);
            return m;
        }
        public static final RpcMessage.Parser<GetQuoteRequest> PARSER = new RpcMessage.Parser<>() {
            @Override public GetQuoteRequest fromBytes(byte[] data) { return new GetQuoteRequest(readUtf8(data)); }
            @Override public GetQuoteRequest fromFieldMap(Map<String, String> f) { return new GetQuoteRequest(f.get("symbol")); }
        };
    }

    public static final class GetQuoteResponse implements RpcMessage {
        public final String symbol;
        public final double bid;
        public final double ask;

        public GetQuoteResponse(String symbol, double bid, double ask) {
            this.symbol = symbol; this.bid = bid; this.ask = ask;
        }

        @Override public byte[] toBytes() {
            try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
                 DataOutputStream out = new DataOutputStream(bos)) {
                out.writeUTF(symbol);
                out.writeDouble(bid);
                out.writeDouble(ask);
                return bos.toByteArray();
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }

        @Override public Map<String, String> toFieldMap() {
            Map<String, String> m = new HashMap<>();
            m.put("symbol", symbol);
            m.put("bid", Double.toString(bid));
            m.put("ask", Double.toString(ask));
            return m;
        }

        public static final RpcMessage.Parser<GetQuoteResponse> PARSER = new RpcMessage.Parser<>() {
            @Override public GetQuoteResponse fromBytes(byte[] data) {
                try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(data))) {
                    return new GetQuoteResponse(in.readUTF(), in.readDouble(), in.readDouble());
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            }
            @Override public GetQuoteResponse fromFieldMap(Map<String, String> f) {
                return new GetQuoteResponse(f.get("symbol"),
                        Double.parseDouble(f.get("bid")), Double.parseDouble(f.get("ask")));
            }
        };
    }

    public static final class SubscribeQuotesRequest implements RpcMessage {
        public final String symbol;
        public SubscribeQuotesRequest(String symbol) { this.symbol = symbol; }

        @Override public byte[] toBytes() { return writeUtf8(symbol); }
        @Override public Map<String, String> toFieldMap() {
            Map<String, String> m = new HashMap<>();
            m.put("symbol", symbol);
            return m;
        }
        public static final RpcMessage.Parser<SubscribeQuotesRequest> PARSER = new RpcMessage.Parser<>() {
            @Override public SubscribeQuotesRequest fromBytes(byte[] data) { return new SubscribeQuotesRequest(readUtf8(data)); }
            @Override public SubscribeQuotesRequest fromFieldMap(Map<String, String> f) { return new SubscribeQuotesRequest(f.get("symbol")); }
        };
    }

    public static final class QuoteUpdate implements RpcMessage {
        public final String symbol;
        public final double bid;
        public final double ask;
        public final long timestampMillis;

        public QuoteUpdate(String symbol, double bid, double ask, long timestampMillis) {
            this.symbol = symbol; this.bid = bid; this.ask = ask; this.timestampMillis = timestampMillis;
        }

        @Override public byte[] toBytes() {
            try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
                 DataOutputStream out = new DataOutputStream(bos)) {
                out.writeUTF(symbol);
                out.writeDouble(bid);
                out.writeDouble(ask);
                out.writeLong(timestampMillis);
                return bos.toByteArray();
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }

        @Override public Map<String, String> toFieldMap() {
            Map<String, String> m = new HashMap<>();
            m.put("symbol", symbol);
            m.put("bid", Double.toString(bid));
            m.put("ask", Double.toString(ask));
            m.put("ts", Long.toString(timestampMillis));
            return m;
        }

        public static final RpcMessage.Parser<QuoteUpdate> PARSER = new RpcMessage.Parser<>() {
            @Override public QuoteUpdate fromBytes(byte[] data) {
                try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(data))) {
                    return new QuoteUpdate(in.readUTF(), in.readDouble(), in.readDouble(), in.readLong());
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            }
            @Override public QuoteUpdate fromFieldMap(Map<String, String> f) {
                return new QuoteUpdate(f.get("symbol"), Double.parseDouble(f.get("bid")),
                        Double.parseDouble(f.get("ask")), Long.parseLong(f.get("ts")));
            }
        };
    }

    private static byte[] writeUtf8(String s) {
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
             DataOutputStream out = new DataOutputStream(bos)) {
            out.writeUTF(s);
            return bos.toByteArray();
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    private static String readUtf8(byte[] data) {
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(data))) {
            return in.readUTF();
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    private QuoteMessages() {}
}
