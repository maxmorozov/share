package com.example.rpc.generated;

import com.example.rpc.core.MethodDescriptor;
import com.example.rpc.core.RpcChannel;
import com.example.rpc.generated.QuoteMessages.GetQuoteRequest;
import com.example.rpc.generated.QuoteMessages.GetQuoteResponse;
import com.example.rpc.generated.QuoteMessages.QuoteUpdate;
import com.example.rpc.generated.QuoteMessages.SubscribeQuotesRequest;

import java.util.concurrent.CompletableFuture;

/**
 * Generated client stub - the only class application code talks to. It has zero
 * knowledge of Liberator or WebSocket; that is entirely decided by which
 * RpcChannel gets injected at bootstrap.
 */
public final class QuoteServiceClient {

    public static final MethodDescriptor<GetQuoteRequest, GetQuoteResponse> GET_QUOTE =
            MethodDescriptor.unary("QuoteService", "GetQuote", GetQuoteResponse.PARSER);

    public static final MethodDescriptor<SubscribeQuotesRequest, QuoteUpdate> SUBSCRIBE_QUOTES =
            MethodDescriptor.serverStream("QuoteService", "SubscribeQuotes", QuoteUpdate.PARSER);

    private final RpcChannel channel;

    public QuoteServiceClient(RpcChannel channel) {
        this.channel = channel;
    }

    public CompletableFuture<GetQuoteResponse> getQuote(String symbol) {
        return channel.unary(GET_QUOTE, new GetQuoteRequest(symbol));
    }

    public RpcChannel.Subscription subscribeQuotes(String symbol, RpcChannel.StreamObserver<QuoteUpdate> observer) {
        return channel.serverStream(SUBSCRIBE_QUOTES, new SubscribeQuotesRequest(symbol), observer);
    }
}
