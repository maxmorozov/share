package com.example.rpc.core;

import java.util.concurrent.CompletableFuture;

/**
 * The single abstraction every generated stub depends on. Concrete implementations
 * (LiberatorChannel, WebSocketChannel, ...) hide the actual transport entirely.
 */
public interface RpcChannel {

    <Req extends RpcMessage, Res extends RpcMessage> CompletableFuture<Res> unary(
            MethodDescriptor<Req, Res> method, Req request);

    <Req extends RpcMessage, Res extends RpcMessage> Subscription serverStream(
            MethodDescriptor<Req, Res> method, Req request, StreamObserver<Res> observer);

    /** Push-based callback for server-streaming methods; mirrors gRPC's StreamObserver. */
    interface StreamObserver<T> {
        void onNext(T value);
        void onError(RpcException error);
        void onCompleted();
    }

    /** Handle returned by serverStream(); cancelling unsubscribes / closes the stream. */
    interface Subscription {
        void cancel();
    }
}
