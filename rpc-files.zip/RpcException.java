package com.example.rpc.core;

/** Transport-agnostic error surfaced to stub callers, regardless of Liberator or WS origin. */
public final class RpcException extends RuntimeException {

    public enum StatusCode {
        OK, CANCELLED, DEADLINE_EXCEEDED, UNAVAILABLE, NOT_FOUND, INTERNAL, UNKNOWN
    }

    private final StatusCode code;

    public RpcException(StatusCode code, String message) {
        super(message);
        this.code = code;
    }

    public RpcException(StatusCode code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
    }

    public StatusCode code() { return code; }
}
