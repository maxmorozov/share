package com.example.rpc.core;

import java.util.Map;

/**
 * Base interface implemented by every generated request/response message class.
 * A real code generator emits toBytes()/toFieldMap() from the same .proto
 * definition, so the two transports never see divergent representations of
 * the same logical message.
 */
public interface RpcMessage {

    /** Protobuf-style binary encoding, used by WebSocketChannel. */
    byte[] toBytes();

    /** Flat field representation, used by LiberatorChannel (StreamLink records). */
    Map<String, String> toFieldMap();

    /** Generated alongside every message type; knows how to parse both forms. */
    interface Parser<T extends RpcMessage> {
        T fromBytes(byte[] data);
        T fromFieldMap(Map<String, String> fields);
    }
}
