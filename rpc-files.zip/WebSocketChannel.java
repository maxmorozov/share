package com.example.rpc.transport.ws;

import com.example.rpc.codec.Codec;
import com.example.rpc.core.MethodDescriptor;
import com.example.rpc.core.RpcChannel;
import com.example.rpc.core.RpcException;
import com.example.rpc.core.RpcMessage;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * RpcChannel implementation that multiplexes every unary call and every active
 * stream over a single WebSocket connection, correlating messages by requestId
 * and encoding message payloads with protobuf.
 */
public final class WebSocketChannel implements RpcChannel, AutoCloseable {

    private final WsTransport transport;
    private final ScheduledExecutorService timers = Executors.newSingleThreadScheduledExecutor();
    private final long defaultTimeoutSeconds;

    private final Map<String, PendingUnary<?>> pendingUnary = new ConcurrentHashMap<>();
    private final Map<String, ActiveStream<?>> activeStreams = new ConcurrentHashMap<>();

    public WebSocketChannel(WsTransport transport, long defaultTimeoutSeconds) {
        this.transport = transport;
        this.defaultTimeoutSeconds = defaultTimeoutSeconds;
        transport.onMessage(this::onMessage);
        transport.onClose(this::onDisconnect);
    }

    @Override
    public <Req extends RpcMessage, Res extends RpcMessage> CompletableFuture<Res> unary(
            MethodDescriptor<Req, Res> method, Req request) {

        String requestId = UUID.randomUUID().toString();
        Codec<Res> codec = new Codec.Protobuf<>(method.responseParser());
        CompletableFuture<Res> future = new CompletableFuture<>();

        ScheduledFuture<?> timeout = timers.schedule(() -> {
            PendingUnary<?> pending = pendingUnary.remove(requestId);
            if (pending != null) {
                pending.future.completeExceptionally(
                        new RpcException(RpcException.StatusCode.DEADLINE_EXCEEDED,
                                "timeout waiting for " + method.fullName()));
            }
        }, defaultTimeoutSeconds, TimeUnit.SECONDS);

        pendingUnary.put(requestId, new PendingUnary<>(future, codec, timeout));
        transport.send(WsEnvelope.request(requestId, method.fullName(), request.toBytes()).encode());
        return future;
    }

    @Override
    public <Req extends RpcMessage, Res extends RpcMessage> Subscription serverStream(
            MethodDescriptor<Req, Res> method, Req request, StreamObserver<Res> observer) {

        String requestId = UUID.randomUUID().toString();
        Codec<Res> codec = new Codec.Protobuf<>(method.responseParser());
        activeStreams.put(requestId, new ActiveStream<>(observer, codec));

        transport.send(WsEnvelope.request(requestId, method.fullName(), request.toBytes()).encode());

        return () -> {
            if (activeStreams.remove(requestId) != null) {
                transport.send(WsEnvelope.cancel(requestId).encode());
            }
        };
    }

    private void onMessage(byte[] raw) {
        WsEnvelope envelope = WsEnvelope.decode(raw);

        PendingUnary<?> pending = pendingUnary.remove(envelope.requestId());
        if (pending != null) {
            completeUnary(pending, envelope);
            return;
        }

        ActiveStream<?> stream = activeStreams.get(envelope.requestId());
        if (stream != null) {
            dispatchStream(envelope.requestId(), stream, envelope);
        }
        // Unknown request id (e.g. a late message after cancel) is safe to ignore.
    }

    @SuppressWarnings("unchecked")
    private <Res extends RpcMessage> void completeUnary(PendingUnary<?> pendingRaw, WsEnvelope envelope) {
        PendingUnary<Res> pending = (PendingUnary<Res>) pendingRaw;
        pending.timeout.cancel(false);
        if (envelope.errorMessage() != null) {
            pending.future.completeExceptionally(
                    new RpcException(RpcException.StatusCode.INTERNAL, envelope.errorMessage()));
            return;
        }
        try {
            pending.future.complete(pending.codec.decode(new Codec.Payload.Bytes(envelope.payload())));
        } catch (Exception e) {
            pending.future.completeExceptionally(
                    new RpcException(RpcException.StatusCode.INTERNAL, "decode failed", e));
        }
    }

    @SuppressWarnings("unchecked")
    private <Res extends RpcMessage> void dispatchStream(String requestId, ActiveStream<?> streamRaw, WsEnvelope envelope) {
        ActiveStream<Res> stream = (ActiveStream<Res>) streamRaw;
        if (envelope.errorMessage() != null) {
            activeStreams.remove(requestId);
            stream.observer.onError(new RpcException(RpcException.StatusCode.INTERNAL, envelope.errorMessage()));
            return;
        }
        if (envelope.streamEnd()) {
            activeStreams.remove(requestId);
            stream.observer.onCompleted();
            return;
        }
        try {
            stream.observer.onNext(stream.codec.decode(new Codec.Payload.Bytes(envelope.payload())));
        } catch (Exception e) {
            activeStreams.remove(requestId);
            stream.observer.onError(new RpcException(RpcException.StatusCode.INTERNAL, "decode failed", e));
        }
    }

    private void onDisconnect(Throwable cause) {
        RpcException err = new RpcException(RpcException.StatusCode.UNAVAILABLE, "connection lost", cause);
        pendingUnary.values().forEach(p -> { p.timeout.cancel(false); p.future.completeExceptionally(err); });
        pendingUnary.clear();
        activeStreams.values().forEach(s -> s.observer.onError(err));
        activeStreams.clear();
        // Reconnecting and re-issuing still-wanted streams is the caller's
        // responsibility - e.g. a higher-level wrapper that remembers active
        // (MethodDescriptor, request) pairs and calls serverStream() again
        // once WsTransport reports it is back online.
    }

    @Override
    public void close() {
        timers.shutdownNow();
    }

    private static final class PendingUnary<Res extends RpcMessage> {
        final CompletableFuture<Res> future;
        final Codec<Res> codec;
        final ScheduledFuture<?> timeout;
        PendingUnary(CompletableFuture<Res> future, Codec<Res> codec, ScheduledFuture<?> timeout) {
            this.future = future; this.codec = codec; this.timeout = timeout;
        }
    }

    private static final class ActiveStream<Res extends RpcMessage> {
        final StreamObserver<Res> observer;
        final Codec<Res> codec;
        ActiveStream(StreamObserver<Res> observer, Codec<Res> codec) {
            this.observer = observer; this.codec = codec;
        }
    }

    /**
     * Minimal length-prefixed wire envelope: requestId, method name, flags, payload.
     * A real system would generate this from its own envelope.proto instead of
     * hand-rolling the framing - shown here in simplified form for clarity.
     */
    private record WsEnvelope(String requestId, String method, boolean streamEnd,
                               boolean cancel, String errorMessage, byte[] payload) {

        static WsEnvelope request(String requestId, String method, byte[] payload) {
            return new WsEnvelope(requestId, method, false, false, null, payload);
        }

        static WsEnvelope cancel(String requestId) {
            return new WsEnvelope(requestId, "", false, true, null, new byte[0]);
        }

        byte[] encode() {
            byte[] idBytes = requestId.getBytes(StandardCharsets.UTF_8);
            byte[] methodBytes = method.getBytes(StandardCharsets.UTF_8);
            int flags = (streamEnd ? 1 : 0) | (cancel ? 2 : 0);
            ByteBuffer buf = ByteBuffer.allocate(4 + idBytes.length + 4 + methodBytes.length + 1 + 4 + payload.length);
            buf.putInt(idBytes.length).put(idBytes);
            buf.putInt(methodBytes.length).put(methodBytes);
            buf.put((byte) flags);
            buf.putInt(payload.length).put(payload);
            return buf.array();
        }

        static WsEnvelope decode(byte[] raw) {
            ByteBuffer buf = ByteBuffer.wrap(raw);
            byte[] idBytes = new byte[buf.getInt()];
            buf.get(idBytes);
            byte[] methodBytes = new byte[buf.getInt()];
            buf.get(methodBytes);
            int flags = buf.get();
            byte[] payload = new byte[buf.getInt()];
            buf.get(payload);
            boolean streamEnd = (flags & 1) != 0;
            boolean cancel = (flags & 2) != 0;
            return new WsEnvelope(new String(idBytes, StandardCharsets.UTF_8),
                    new String(methodBytes, StandardCharsets.UTF_8), streamEnd, cancel, null, payload);
        }
    }
}
