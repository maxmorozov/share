package com.example.rpc.transport.ws;

import java.util.function.Consumer;

/**
 * Thin abstraction over whatever WebSocket client you actually use
 * (Jakarta WebSocket, Java-WebSocket, Netty, ...). WebSocketChannel only
 * depends on this interface - swap the implementation without touching any
 * RPC logic.
 */
public interface WsTransport {
    void send(byte[] data);
    void onMessage(Consumer<byte[]> handler);
    void onClose(Consumer<Throwable> handler);
}
