Macro {
  area="Shell"; key="CtrlC"; flags=""; description="Calculator"; action = function()

Keys('F11')
Keys('c')

  end;
}

