Macro {
  area="Shell"; key="Space"; flags="EmptyCommandLine"; description="Panel: Use Space to select files"; action = function()
Keys('Ins')
  end;
}

