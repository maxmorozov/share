Macro {
  area="Viewer"; key="CtrlF6"; flags=""; description="Calculator"; action = function()

Keys('F11')
Keys('l')
Keys('Enter')

  end;
}

